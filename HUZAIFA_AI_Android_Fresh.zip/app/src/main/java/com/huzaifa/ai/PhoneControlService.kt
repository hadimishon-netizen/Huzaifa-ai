package com.huzaifa.ai

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.content.Intent
import android.net.Uri
import android.os.Bundle

class PhoneControlService : AccessibilityService() {
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    override fun onServiceConnected() { instance = this }

    fun handle(command: String) {
        val c = command.lowercase()
        when {
            c.contains("পেছনে") || c.contains("back") -> performGlobalAction(GLOBAL_ACTION_BACK)
            c.contains("হোম") || c.contains("home") -> performGlobalAction(GLOBAL_ACTION_HOME)
            c.contains("নিচে স্ক্রল") || c.contains("scroll down") -> scroll(true)
            c.contains("উপরে স্ক্রল") || c.contains("scroll up") -> scroll(false)
            c.contains("youtube") -> openApp("com.google.android.youtube")
            c.contains("হোয়াটসঅ্যাপ") || c.contains("whatsapp") -> openApp("com.whatsapp")
            c.contains("ফেসবুক") || c.contains("facebook") -> openApp("com.facebook.katana")
            c.contains("গ্যালারি") || c.contains("gallery") || c.contains("ফটো") -> openGallery()
            else -> {
                // Unknown commands are deliberately not executed.
            }
        }
    }

    private fun openApp(packageName: String) {
        val launch = packageManager.getLaunchIntentForPackage(packageName) ?: return
        launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        startActivity(launch)
    }

    private fun openGallery() {
        val i = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(Uri.parse("content://media/internal/images/media"), "image/*")
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        try { startActivity(i) } catch (_: Exception) {}
    }

    private fun scroll(down: Boolean) {
        val root = rootInActiveWindow ?: return
        val node = findScrollable(root)
        if (node != null) {
            val action = if (down) AccessibilityNodeInfo.ACTION_SCROLL_FORWARD else AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD
            node.performAction(action)
        }
        root.recycle()
    }

    private fun findScrollable(node: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        if (node.isScrollable) return node
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            val found = findScrollable(child)
            if (found != null) return found
        }
        return null
    }

    companion object {
        @Volatile private var instance: PhoneControlService? = null
        fun perform(command: String) { instance?.handle(command) }
    }
}
