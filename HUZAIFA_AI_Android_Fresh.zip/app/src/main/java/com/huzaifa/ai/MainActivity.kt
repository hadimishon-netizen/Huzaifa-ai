package com.huzaifa.ai

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.provider.Settings
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.RecognitionListener
import android.speech.SpeechRecognizer.ERROR_NO_MATCH
import android.speech.SpeechRecognizer.ERROR_SPEECH_TIMEOUT
import android.widget.*
import android.graphics.Color
import android.view.Gravity
import android.view.ViewGroup
import androidx.activity.ComponentActivity
import androidx.core.app.ActivityCompat
import java.util.Locale

class MainActivity : ComponentActivity() {
    private var recognizer: SpeechRecognizer? = null
    private lateinit var status: TextView
    private lateinit var command: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(16,23,45)
        window.navigationBarColor = Color.rgb(16,23,45)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(28, 36, 28, 28)
            setBackgroundColor(Color.rgb(16,23,45))
        }
        val title = TextView(this).apply {
            text = "HUZAIFA AI"
            textSize = 30f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
        }
        val sub = TextView(this).apply {
            text = "YOUR PERSONAL PHONE ASSISTANT"
            textSize = 12f; setTextColor(Color.rgb(160,185,240)); gravity = Gravity.CENTER
        }
        status = TextView(this).apply {
            text = "আমি প্রস্তুত। মাইক্রোফোন চাপুন।"
            textSize = 16f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
            setPadding(0,36,0,18)
        }
        command = TextView(this).apply {
            text = "আপনার নির্দেশ এখানে দেখা যাবে"
            textSize = 14f; setTextColor(Color.LTGRAY); gravity = Gravity.CENTER
            setPadding(0,0,0,24)
        }
        val listen = Button(this).apply {
            text = "🎙  কথা বলুন"
            textSize = 18f
            setOnClickListener { startListening() }
        }
        val accessibility = Button(this).apply {
            text = "ফোন কন্ট্রোল চালু করুন"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        }
        val help = TextView(this).apply {
            text = "প্রথমে Accessibility চালু করুন। তারপর বলুন: “YouTube খোলো”, “পেছনে যাও”, “নিচে স্ক্রল করো”, “হোমে যাও”।"
            textSize = 14f; setTextColor(Color.rgb(205,215,235)); gravity = Gravity.CENTER
            setPadding(0,24,0,0)
        }
        listOf(title,sub,status,command,listen,accessibility,help).forEach {
            layout.addView(it, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { bottomMargin=14 })
        }
        setContentView(layout)
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECORD_AUDIO), 10)
        }
    }

    private fun startListening() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            status.text = "এই ফোনে Speech Recognition পাওয়া যাচ্ছে না"; return
        }
        recognizer?.destroy()
        recognizer = SpeechRecognizer.createSpeechRecognizer(this)
        recognizer?.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) { status.text = "শুনছি..." }
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() { status.text = "নির্দেশ বুঝছি..." }
            override fun onError(error: Int) { status.text = "আবার চেষ্টা করুন" }
            override fun onResults(results: Bundle?) {
                val spoken = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
                command.text = "আপনি বলেছেন: $spoken"
                status.text = "নির্দেশ পরীক্ষা করছি..."
                PhoneControlService.perform(spoken)
                status.text = "নির্দেশ পাঠানো হয়েছে"
            }
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "bn-BD")
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "bn-BD")
            putExtra(RecognizerIntent.EXTRA_PROMPT, "হুজাইফা AI-কে নির্দেশ দিন")
        }
        recognizer?.startListening(intent)
    }

    override fun onDestroy() {
        recognizer?.destroy()
        super.onDestroy()
    }
}
